Java Multithreading Programs

Files:
1. ThreadClassDemo.java - Method 1: extends Thread
2. RunnableDemo.java - Method 2: implements Runnable

Compile and run Method 1:
    javac ThreadClassDemo.java
    java ThreadClassDemo

Compile and run Method 2:
    javac RunnableDemo.java
    java RunnableDemo

Both programs run continuously until you stop them (for example, press Ctrl+C in the terminal).
Because threads execute concurrently, the exact order of printed messages can vary.
